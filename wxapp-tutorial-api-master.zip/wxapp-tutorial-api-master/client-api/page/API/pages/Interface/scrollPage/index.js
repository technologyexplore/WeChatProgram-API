Page({
    onShow() {
        wx.pageScrollTo({
            scrollTop: 30,
            duration: 1200
        });
    }
})