Page({
  onLoad: function () {
    wx.uploadFile({
      url: 'upload',   //服务端地址
      filePath: 'example.jpg', //文件资源的路径
      name: 'file',                //文件对应的Key,文件名字
      formData: {                  //文件附加信息
          // 'user'：‘test’
      },
      success(res){               //异步的，成功回调函数
         console.log(res.data)
      }
  })
  },
  /* 转发*/
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '转发dom',
      path: `pages/index/index`,
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
        var shareTickets = res.shareTickets;
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  }
})
