Page({
  toast1Tap: function () {
    wx.showToast({
      title: "默认",
      success(){
        console.log('成功')
      }
    })
  },
  toast2Tap: function () {
    wx.showToast({
      title: "duration 3000",
      duration: 3000
    })
  },
  toast3Tap: function () {
    wx.showToast({
      title: "loading",
      icon: "loading",
      duration: 5000
    })
  },
  hideToast: function () {
    wx.hideToast()
  },
  toast4Tap: function (){
    // (选择窗)
    wx.showModal({
    　　title: '提示',
    　　content: '这是一个模态弹窗',
    　　success (res) {
    　　　　if (res.confirm) {
    　　　　　　console.log('用户点击确定')
    　　　　} else if (res.cancel) {
    　　　　　　console.log('用户点击取消')
    　　　　}
    　　}
    })
  }
})
