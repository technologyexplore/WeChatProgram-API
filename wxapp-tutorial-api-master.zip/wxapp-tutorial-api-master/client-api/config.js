/**
 * 小程序配置文件
 */


var config = {

    // 测试的请求地址，用于测试会话
    requestUrl: `http://mrp-dev01.dotfashion.cn/mrp/health`,

    // 测试的信道服务接口
    tunnelUrl: `ws://127.0.0.1:3306`,

    // 上传文件接口
    uploadFileUrl: `http://mrp-test01.dotfashion.cn/java/fabric/image/upload`,

    // 下载文件接口
    downloadFileUrl: `http://img.fabric.dotfashion.cn/images_fabric/2020/05/27/15905782933887433933.png`
};

module.exports = config
